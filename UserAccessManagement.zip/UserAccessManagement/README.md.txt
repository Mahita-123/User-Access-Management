# User Access Management System

## Overview
The **User Access Management System** is a web-based application designed to manage user access to software applications within an organization. It allows employees to request access, managers to approve/reject requests, and admins to manage software applications.

---

## Features
1. **User Registration and Login**:
   - Employees can sign up and log in to the system.
   - Login redirects users to pages based on their roles.

2. **Role-Based Access**:
   - **Employee**: Request access to software applications.
   - **Manager**: Approve or reject pending access requests.
   - **Admin**: Manage software applications.

3. **Software Management**:
   - Admins can create software applications with access levels.

4. **Access Request System**:
   - Employees can request access to software with reasons.
   - Managers can view and process requests.

5. **Database Integration**:
   - PostgreSQL database for storing users, software, and requests.

---

## Technologies Used
- **Backend**: Java Servlets
- **Frontend**: JSP, HTML, CSS
- **Database**: PostgreSQL
- **Build Tool**: Maven
- **Server**: Apache Tomcat

---

## Project Structure
